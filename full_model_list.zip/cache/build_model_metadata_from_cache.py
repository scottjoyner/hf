#!/usr/bin/env python3
"""
Build a wide CSV of Hugging Face model metadata from cached /api/models JSONs.

Inputs
------
- --cache: directory containing HF JSON files (e.g. cache/)
    Expected naming (but not enforced):
        "<org>__<repo>.json"
        "model_<org>__<repo>.json"
    where "__" corresponds to "/".

Output
------
- --output-csv: CSV with ONE ROW PER MODEL, containing:
    - Core, computed columns:
        repo_id, canonical_url, name_hf_slug,
        parameters, parameters_readable,
        file_count, used_storage_bytes (best-effort),
        has_safetensors, has_bin, has_pt, has_onnx, has_tflite, has_gguf,
        siblings_total_size_bytes
    - Plus EVERY FIELD from the JSON payload, flattened:
        - Top-level keys: id, _id, author, downloads, likes, ...
        - Nested dicts: cardData.language -> "cardData.language"
        - Lists of primitives: join with ";" (e.g. languages, tags)
        - Lists of dicts: JSON string (e.g. siblings, model-index, etc.)

Design goals
------------
- DO NOT drop information:
    - Any nested structure that cannot be cleanly represented as a simple
      string/number becomes a JSON string in a single cell.
- Handle weird / incomplete JSON gracefully:
    - If a file can't be parsed, log a warning and continue.

Usage
-----
    python build_model_metadata_from_cache.py \
        --cache cache \
        --output-csv data/model_metadata_full.csv
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd

# Optional progress bar
try:
    from tqdm import tqdm  # type: ignore
    _tqdm = tqdm
except Exception:  # pragma: no cover
    def _tqdm(x, **kwargs):
        return x


# ---------------------------------------------------------------------------
# Logging helper
# ---------------------------------------------------------------------------

def log(msg: str) -> None:
    print(msg, file=sys.stderr)


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def parse_params_to_int(*vals: Any) -> Optional[int]:
    """
    Parse parameters from multiple possible sources:
      - int/float directly
      - strings like '14m', '7B', '1.3b', '567755777'
    Returns int or None.
    """

    def _from_str(s: str) -> Optional[int]:
        t = s.strip().lower().replace(",", "")
        if not t:
            return None
        if t.endswith("k"):
            return int(float(t[:-1]) * 1_000)
        if t.endswith("m"):
            return int(float(t[:-1]) * 1_000_000)
        if t.endswith("b"):
            return int(float(t[:-1]) * 1_000_000_000)
        return int(float(t))

    for v in vals:
        if v is None:
            continue
        if isinstance(v, int):
            return v
        if isinstance(v, float) and not math.isnan(v):
            return int(v)
        if isinstance(v, str) and v.strip():
            try:
                parsed = _from_str(v)
                if parsed is not None:
                    return parsed
            except Exception:
                continue
    return None


def readable_int(n: Optional[int]) -> str:
    if n is None:
        return ""
    if n >= 1_000_000_000:
        return f"{n/1_000_000_000:.2f}B"
    if n >= 1_000_000:
        return f"{n/1_000_000:.2f}M"
    if n >= 1_000:
        return f"{n/1_000:.2f}K"
    return str(n)


def flatten_dict(
    obj: Any,
    parent_key: str = "",
    out: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Flatten a nested dict into a single level with dot-separated keys.

    Rules:
      - dict: recurse, joining keys with "."
      - list:
          * if list of primitives (str/int/float/bool/None) -> join with ';'
          * else (list of dicts or mixed) -> JSON string
      - scalars: stored directly
    """
    if out is None:
        out = {}

    if isinstance(obj, dict):
        for k, v in obj.items():
            new_key = f"{parent_key}.{k}" if parent_key else k
            flatten_dict(v, new_key, out)
    elif isinstance(obj, list):
        # Try to decide if it's a list of primitives or structures
        non_null = None
        for v in obj:
            if v is not None:
                non_null = v
                break

        if non_null is None:
            # all None or empty list
            out[parent_key] = ""
        elif isinstance(non_null, (str, int, float, bool)):
            # list of primitives -> join with ";"
            def _to_str(x: Any) -> str:
                if x is None:
                    return ""
                return str(x)

            out[parent_key] = ";".join(_to_str(x) for x in obj)
        else:
            # list of dicts or complex types -> JSON string
            try:
                out[parent_key] = json.dumps(obj, ensure_ascii=False)
            except Exception:
                out[parent_key] = str(obj)
    else:
        if parent_key:
            out[parent_key] = obj

    return out


def derive_repo_id_from_filename(path: Path) -> Optional[str]:
    """
    Attempt to derive repo_id from filename, assuming patterns like:
      - org__repo.json
      - model_org__repo.json
    """
    name = path.name
    if name.endswith(".json"):
        name = name[:-5]

    if name.startswith("model_"):
        name = name[len("model_") :]

    if "__" in name:
        return name.replace("__", "/")

    # Fallback: if no "__", we cannot be sure; return None
    return None


# ---------------------------------------------------------------------------
# File / sibling helpers
# ---------------------------------------------------------------------------

def derive_file_flags_and_sizes(siblings: Any) -> Tuple[Dict[str, int], Dict[str, bool], int]:
    """
    Inspect 'siblings' and compute:
      - sizes: {"count": int, "bytes": int}
      - flags: {"has_safetensors", "has_bin", "has_pt", "has_onnx", "has_tflite", "has_gguf"}
      - known_bytes_sum: int
    """
    count = 0
    total_bytes = 0
    flags = {
        "has_safetensors": False,
        "has_bin": False,
        "has_pt": False,
        "has_onnx": False,
        "has_tflite": False,
        "has_gguf": False,
    }

    if not isinstance(siblings, list):
        return {"count": 0, "bytes": 0}, flags, 0

    for s in siblings:
        if not isinstance(s, dict):
            continue
        name = s.get("rfilename") or ""
        if not name:
            continue
        count += 1
        sz = s.get("size")
        if isinstance(sz, (int, float)) and sz >= 0:
            total_bytes += int(sz)

        lower = str(name).lower()
        if lower.endswith(".safetensors") or lower.endswith(".safetensors.index.json"):
            flags["has_safetensors"] = True
        if lower.endswith(".bin") or lower.endswith(".bin.index.json"):
            flags["has_bin"] = True
        if lower.endswith(".pt"):
            flags["has_pt"] = True
        if lower.endswith(".onnx"):
            flags["has_onnx"] = True
        if lower.endswith(".tflite"):
            flags["has_tflite"] = True
        if lower.endswith(".gguf"):
            flags["has_gguf"] = True

    return {"count": count, "bytes": total_bytes}, flags, total_bytes


# ---------------------------------------------------------------------------
# Main per-model row builder
# ---------------------------------------------------------------------------

def build_row_from_json(js: Dict[str, Any], source_path: Path) -> Dict[str, Any]:
    """
    Given a single HF /api/models JSON and its source path, produce a row dict
    with:
      - core computed fields
      - full flattened JSON contents
    """
    row: Dict[str, Any] = {}

    # Try to work out repo_id
    repo_id = (
        js.get("id")
        or js.get("modelId")
        or derive_repo_id_from_filename(source_path)
    )

    if not isinstance(repo_id, str) or not repo_id:
        repo_id = ""

    row["repo_id"] = repo_id

    # Canonical URL & slug
    if repo_id:
        row["canonical_url"] = f"https://huggingface.co/{repo_id}"
        repo_tail = repo_id.split("/")[-1]
        org = repo_id.split("/")[0] if "/" in repo_id else ""
        row["name_hf_slug"] = (
            f"huggingface-{org}-{repo_tail}" if org else f"huggingface-{repo_tail}"
        )
    else:
        row["canonical_url"] = ""
        row["name_hf_slug"] = ""

    # Parameters from multiple possible places
    safetensors = js.get("safetensors") or {}
    card = js.get("cardData") or {}
    cfg = js.get("config") or {}

    params_int = parse_params_to_int(
        safetensors.get("total"),
        card.get("parameter_count"),
        cfg.get("num_parameters"),
        cfg.get("num_params"),
    )
    row["parameters"] = params_int if params_int is not None else ""
    row["parameters_readable"] = readable_int(params_int)

    # Siblings-derived flags & sizes
    siblings = js.get("siblings") or []
    sizes, flags, known_bytes_sum = derive_file_flags_and_sizes(siblings)
    row["file_count"] = sizes["count"]
    row["siblings_total_size_bytes"] = known_bytes_sum

    # usedStorage (if present) takes precedence as the canonical "used_storage_bytes"
    used_storage = js.get("usedStorage")
    if isinstance(used_storage, (int, float)):
        row["used_storage_bytes"] = int(used_storage)
    else:
        row["used_storage_bytes"] = known_bytes_sum if known_bytes_sum else ""

    for k, v in flags.items():
        row[k] = v

    # Flatten the entire JSON structure into additional columns
    flattened = flatten_dict(js)
    # Merge flattened into row, without overwriting core fields
    for key, value in flattened.items():
        if key in row:
            continue
        row[key] = value

    # Source file info for traceability
    row["__source_file"] = str(source_path)

    return row


# ---------------------------------------------------------------------------
# Main CLI
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(
        description=(
            "Build a wide CSV of Hugging Face model metadata from cached "
            "/api/models JSON files."
        )
    )
    ap.add_argument(
        "--cache",
        default="cache",
        help="Directory containing cached HF model JSONs (default: cache)",
    )
    ap.add_argument(
        "--output-csv",
        default="data/model_metadata_full.csv",
        help="Output CSV path (default: data/model_metadata_full.csv)",
    )

    args = ap.parse_args()

    cache_dir = Path(args.cache)
    if not cache_dir.exists() or not cache_dir.is_dir():
        raise SystemExit(f"Cache dir not found or not a directory: {cache_dir}")

    json_files: List[Path] = sorted(cache_dir.rglob("*.json"))
    if not json_files:
        raise SystemExit(f"No JSON files found under: {cache_dir}")

    log(f"[INFO] Found {len(json_files)} JSON files under {cache_dir}")

    rows: List[Dict[str, Any]] = []

    for path in _tqdm(json_files, desc="Processing JSON files"):
        try:
            text = path.read_text(encoding="utf-8")
        except Exception as e:
            log(f"[WARN] Failed to read {path}: {e}")
            continue

        try:
            js = json.loads(text)
        except Exception as e:
            log(f"[WARN] Failed to parse JSON in {path}: {e}")
            continue

        if not isinstance(js, dict):
            log(f"[WARN] JSON root is not an object in {path}; skipping.")
            continue

        try:
            row = build_row_from_json(js, path)
            rows.append(row)
        except Exception as e:
            log(f"[WARN] Failed to build row for {path}: {e}")
            continue

    if not rows:
        raise SystemExit("No valid rows built from cache JSONs; nothing to write.")

    # Determine full column set
    all_keys: List[str] = []
    key_set = set()
    for row in rows:
        for k in row.keys():
            if k not in key_set:
                key_set.add(k)
                all_keys.append(k)

    # Prefer some core columns at the front
    core_order = [
        "repo_id",
        "canonical_url",
        "name_hf_slug",
        "parameters",
        "parameters_readable",
        "file_count",
        "used_storage_bytes",
        "siblings_total_size_bytes",
        "has_safetensors",
        "has_bin",
        "has_pt",
        "has_onnx",
        "has_tflite",
        "has_gguf",
        "__source_file",
    ]
    # Append remaining columns in the order they were discovered
    final_cols = core_order + [k for k in all_keys if k not in core_order]

    df = pd.DataFrame(rows)[final_cols]

    out_path = Path(args.output_csv)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)
    log(f"[OK] Wrote {len(df)} rows and {len(final_cols)} columns to {out_path}")


if __name__ == "__main__":
    main()
# python build_model_metadata_from_cache.py
#         --cache C:\Users\AMD\git\hf\scripts\cache
#         --output-csv model_metadata_full.csv