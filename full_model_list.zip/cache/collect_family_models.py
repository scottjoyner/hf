#!/usr/bin/env python3
"""
collect_family_models.py

Collect Hugging Face model "families" (collections + individual model links)
and emit a CSV of model URLs suitable as input to build_model_metadata.py.

Features
--------

- Accepts:
    * HF collections (families), e.g.
        https://huggingface.co/collections/ibm-granite/granite-40-language-models
        https://huggingface.co/collections/mistralai/ministral-3
    * Individual model URLs, e.g.
        https://huggingface.co/ibm-granite/granite-4.0-h-tiny
    * Bare repo_ids, e.g.
        ibm-granite/granite-4.0-h-tiny
    * CSV files of inputs via --input-csv, with a column of URLs/IDs.

- Outputs CSV:
    model_name: HF repo_id (e.g. "ibm-granite/granite-4.0-h-tiny")
    url:        canonical HF URL
    source_collection_slug / owner / title: context for the "family"

- Optional: --download-cache
    * For each unique model, calls:
        https://huggingface.co/api/models/<repo_id>?expand=cardData&expand=siblings&expand=transformersInfo
      and writes:
        <cache_dir>/<org>__<repo>.json
      which matches the expectations of build_model_metadata.py.

Usage
-----

Example: Granite 4.0 + Mistral 3 families

  python collect_family_models.py \
      --output data/models_enriched_families.csv \
      --cache-dir cache \
      --download-cache \
      --dedupe \
      "https://huggingface.co/collections/ibm-granite/granite-40-language-models" \
      "https://huggingface.co/collections/ibm-granite/granite-40-nano-language-models" \
      "https://huggingface.co/collections/mistralai/ministral-3" \
      "https://huggingface.co/collections/mistralai/mistral-large-3"

Then:

  python build_model_metadata.py \
      --input data/models_enriched_families.csv \
      --cache cache \
      --output-csv data/model_metadata_families.csv

CSV input example (families.csv):

    url
    https://huggingface.co/collections/ibm-granite/granite-40-language-models
    https://huggingface.co/collections/mistralai/ministral-3

Run:

  python collect_family_models.py \
      --input-csv families.csv \
      --output data/models_enriched_families.csv \
      --cache-dir cache \
      --download-cache --dedupe

Requirements
------------

- huggingface_hub (you already have this)
- requests (pip install requests)

Token
-----

- Uses --token (or HF_TOKEN env) for gated/private models.
"""

import argparse
import csv
import os
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional
from urllib.parse import urlparse, quote

import requests

try:
    from huggingface_hub import get_collection
except ImportError:
    print(
        "ERROR: huggingface_hub not installed.\n"
        "Please install it (e.g. pip install huggingface_hub).",
        file=sys.stderr,
    )
    sys.exit(1)

# Optional progress bar
try:
    from tqdm import tqdm  # type: ignore
    _tqdm = tqdm
except Exception:  # pragma: no cover
    def _tqdm(x, **kwargs):
        return x


# ---------------------------------------------------------------------------
# URL / repo_id parsing helpers
# ---------------------------------------------------------------------------

def is_hf_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
        return "huggingface.co" in (parsed.netloc or "")
    except Exception:
        return False


def parse_collection_slug_from_url(url: str) -> Optional[str]:
    """
    Turn a collections URL into a slug suitable for get_collection().

    e.g. "https://huggingface.co/collections/ibm-granite/granite-40-language-models"
         -> "ibm-granite/granite-40-language-models"
    """
    try:
        parsed = urlparse(url)
        parts = [p for p in parsed.path.strip("/").split("/") if p]
        if len(parts) >= 3 and parts[0] == "collections":
            owner = parts[1]
            slug = parts[2]
            return f"{owner}/{slug}"
        return None
    except Exception:
        return None


def extract_repo_id_from_url_or_id(s: str) -> Optional[str]:
    """
    Accept either a full HF URL or a bare repo_id and return repo_id.

    Examples:
      "https://huggingface.co/ibm-granite/granite-4.0-h-tiny"
          -> "ibm-granite/granite-4.0-h-tiny"
      "ibm-granite/granite-4.0-h-tiny"
          -> "ibm-granite/granite-4.0-h-tiny"
    """
    if not isinstance(s, str):
        return None
    s = s.strip()
    if not s:
        return None

    if "huggingface.co" in s:
        parsed = urlparse(s)
        tail = parsed.path.split("?", 1)[0].split("#", 1)[0].strip("/")
        parts = [p for p in tail.split("/") if p]
        if not parts:
            return None

        # URLs like /models/<org>/<repo> exist, but main UI is /<org>/<repo>
        if parts[0] == "models":
            parts = parts[1:]

        if not parts:
            return None

        if len(parts) >= 2:
            return f"{parts[0]}/{parts[1]}"
        else:
            # single-tenant repo like "bert-base-uncased"
            return parts[0]

    # Assume it's already a repo_id
    return s


# ---------------------------------------------------------------------------
# Collection handling
# ---------------------------------------------------------------------------

def collect_from_collection(
    slug: str,
    token: Optional[str],
    rows: List[Dict[str, str]],
) -> None:
    """
    Use huggingface_hub.get_collection(slug) to expand a collection
    into model rows.
    """
    try:
        col = get_collection(slug, token=token)
    except Exception as e:
        print(f"[WARN] Failed to fetch collection '{slug}': {e}", file=sys.stderr)
        return

    owner = getattr(col, "owner", "") or ""
    title = getattr(col, "title", "") or ""
    collection_slug = getattr(col, "slug", slug)

    for item in getattr(col, "items", []) or []:
        item_type = getattr(item, "item_type", None)
        if item_type != "model":
            # skip datasets/spaces/papers/sub-collections
            continue

        repo_id = getattr(item, "item_id", "") or ""
        # Docs say this is usually a bare repo_id, but be paranoid:
        if repo_id.startswith("models/"):
            repo_id = repo_id.split("/", 1)[1]

        if not repo_id:
            continue

        canonical_url = f"https://huggingface.co/{repo_id}"
        rows.append(
            {
                "model_name": repo_id,
                "url": canonical_url,
                "source_collection_slug": collection_slug,
                "source_collection_owner": owner,
                "source_collection_title": title,
            }
        )


def collect_from_single_input(
    inp: str,
    token: Optional[str],
    rows: List[Dict[str, str]],
) -> None:
    """
    Handle one input string:
      - if it's a collections URL, expand via get_collection()
      - otherwise treat it as a single repo (URL or repo_id)
    """
    slug = parse_collection_slug_from_url(inp) if is_hf_url(inp) else None

    if slug:
        print(f"[INFO] Expanding collection: {slug}", file=sys.stderr)
        collect_from_collection(slug, token=token, rows=rows)
        return

    # Fallback: just a repo_id or model URL
    repo_id = extract_repo_id_from_url_or_id(inp)
    if not repo_id:
        print(f"[WARN] Could not parse repo_id from input: {inp}", file=sys.stderr)
        return

    canonical_url = f"https://huggingface.co/{repo_id}"
    rows.append(
        {
            "model_name": repo_id,
            "url": canonical_url,
            "source_collection_slug": "",
            "source_collection_owner": "",
            "source_collection_title": "",
        }
    )


# ---------------------------------------------------------------------------
# CSV input helpers
# ---------------------------------------------------------------------------

def load_inputs_from_csv(path: Path) -> List[str]:
    """
    Load inputs from a CSV. We try to be forgiving:
        - Prefer a column named 'url'
        - Else prefer 'input'
        - Else use the first column
    """
    inputs: List[str] = []
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            print(f"[WARN] CSV {path} has no header; skipping.", file=sys.stderr)
            return inputs

        fieldnames = [fn for fn in reader.fieldnames if fn is not None]
        col_name: Optional[str] = None
        for candidate in ("url", "input", "hf_url", "hf_input"):
            if candidate in fieldnames:
                col_name = candidate
                break

        if col_name is None:
            # Fallback: first column
            col_name = fieldnames[0]
            print(
                f"[INFO] CSV {path}: using first column '{col_name}' as input.",
                file=sys.stderr,
            )
        else:
            print(
                f"[INFO] CSV {path}: using column '{col_name}' as input.",
                file=sys.stderr,
            )

        for row in reader:
            val = (row.get(col_name) or "").strip()
            if val:
                inputs.append(val)

    return inputs


# ---------------------------------------------------------------------------
# Download /cache helpers
# ---------------------------------------------------------------------------

def safe_cache_filename(repo_id: str) -> str:
    """
    Convert repo_id into a safe filename:
        'org/name' -> 'org__name.json'
    """
    return repo_id.replace("/", "__") + ".json"


def download_model_json(
    repo_id: str,
    cache_dir: Path,
    token: Optional[str],
    force: bool = False,
) -> None:
    """
    Download /api/models/<repo_id> JSON and write it in cache_dir.

    - Uses ?expand=cardData&expand=siblings&expand=transformersInfo to
      make sure we get everything build_model_metadata.py expects.
    - Respects HF token for private/gated models.
    """
    filename = safe_cache_filename(repo_id)
    out_path = cache_dir / filename

    if out_path.exists() and not force:
        print(f"[cache] {repo_id} -> {out_path} (exists, skip)", file=sys.stderr)
        return

    cache_dir.mkdir(parents=True, exist_ok=True)

    base_url = "https://huggingface.co/api/models"
    # Ensure safe encoding of repo_id without breaking the /
    encoded_repo_id = quote(repo_id, safe="/")
    url = f"{base_url}/{encoded_repo_id}"

    params = [
        ("expand", "cardData"),
        ("expand", "siblings"),
        ("expand", "transformersInfo"),
    ]

    headers = {"Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    try:
        resp = requests.get(url, headers=headers, params=params, timeout=30)
    except Exception as e:
        print(f"[ERROR] HTTP error for {repo_id}: {e}", file=sys.stderr)
        return

    if resp.status_code == 200:
        try:
            # Validate JSON before writing
            _ = resp.json()
        except Exception as e:
            print(f"[ERROR] Invalid JSON for {repo_id}: {e}", file=sys.stderr)
            return

        out_path.write_text(resp.text, encoding="utf-8")
        print(f"[OK] cached {repo_id} -> {out_path}", file=sys.stderr)
    else:
        snippet = resp.text[:200].replace("\n", " ")
        print(
            f"[WARN] HTTP {resp.status_code} for {repo_id}: {snippet}",
            file=sys.stderr,
        )


def download_cache_for_models(
    repo_ids: Iterable[str],
    cache_dir: Path,
    token: Optional[str],
    force: bool = False,
) -> None:
    """
    Iterate over repo_ids and ensure each has a JSON in cache_dir.
    """
    unique_ids = sorted({rid for rid in repo_ids if rid})
    if not unique_ids:
        print("[INFO] No repo_ids to cache.", file=sys.stderr)
        return

    print(
        f"[INFO] Downloading HF metadata for {len(unique_ids)} models...",
        file=sys.stderr,
    )

    for rid in _tqdm(unique_ids, desc="Caching models"):
        download_model_json(rid, cache_dir=cache_dir, token=token, force=force)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(argv: Optional[List[str]] = None) -> None:
    ap = argparse.ArgumentParser(
        description=(
            "Collect model URLs for Hugging Face families (collections) and "
            "optionally download /api/models JSON into a cache directory."
        )
    )
    ap.add_argument(
        "inputs",
        nargs="*",
        help=(
            "Zero or more Hugging Face links or repo_ids.\n"
            "Examples:\n"
            "  https://huggingface.co/collections/ibm-granite/granite-40-language-models\n"
            "  https://huggingface.co/collections/mistralai/ministral-3\n"
            "  https://huggingface.co/ibm-granite/granite-4.0-h-tiny\n"
            "  ibm-granite/granite-4.0-h-tiny"
        ),
    )
    ap.add_argument(
        "--input-csv",
        action="append",
        default=None,
        help=(
            "CSV file containing inputs (URLs or repo_ids). "
            "We will look for a column named 'url', then 'input', then use "
            "the first column if neither is present. Can be specified multiple times."
        ),
    )
    ap.add_argument(
        "--output",
        default="data/models_enriched_families.csv",
        help="Output CSV path (default: data/models_enriched_families.csv)",
    )
    ap.add_argument(
        "--dedupe",
        action="store_true",
        help="Drop duplicate model_name (repo_id) rows across all inputs.",
    )
    ap.add_argument(
        "--download-cache",
        action="store_true",
        help=(
            "Download Hugging Face /api/models JSON for each unique model into "
            "the cache directory (see --cache-dir)."
        ),
    )
    ap.add_argument(
        "--cache-dir",
        default="cache",
        help="Cache directory for model JSONs (default: cache)",
    )
    ap.add_argument(
        "--force-refresh",
        action="store_true",
        help="Re-download JSON even if a cache file already exists.",
    )
    ap.add_argument(
        "--token",
        default=os.getenv("HF_TOKEN"),
        help="Optional HF access token (default: env HF_TOKEN).",
    )

    args = ap.parse_args(argv)

    # Aggregate all raw inputs: CLI positional + CSV sources
    raw_inputs: List[str] = []

    # Positional inputs
    for inp in args.inputs:
        s = inp.strip()
        if s:
            raw_inputs.append(s)

    # CSV inputs
    if args.input_csv:
        for csv_path in args.input_csv:
            p = Path(csv_path)
            if not p.exists():
                print(f"[WARN] Input CSV not found: {p}", file=sys.stderr)
                continue
            raw_inputs.extend(load_inputs_from_csv(p))

    if not raw_inputs:
        print(
            "[ERROR] No inputs provided. Use positional URLs/repo_ids and/or --input-csv.",
            file=sys.stderr,
        )
        sys.exit(1)

    rows: List[Dict[str, str]] = []
    for inp in raw_inputs:
        collect_from_single_input(inp, token=args.token, rows=rows)

    if not rows:
        print("[WARN] No models collected; nothing to write.", file=sys.stderr)
        return

    # Dedupe models if requested
    if args.dedupe:
        seen: Dict[str, Dict[str, str]] = {}
        for row in rows:
            rid = row.get("model_name")
            if not rid:
                continue
            # First occurrence wins
            if rid not in seen:
                seen[rid] = row
        rows = list(seen.values())

    # Ensure output directory
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Write CSV
    fieldnames = [
        "model_name",
        "url",
        "source_collection_slug",
        "source_collection_owner",
        "source_collection_title",
    ]
    with out_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

    print(
        f"[OK] Wrote {len(rows)} models to {out_path}",
        file=sys.stderr,
    )

    # Optional cache download
    if args.download_cache:
        cache_dir = Path(args.cache_dir)
        repo_ids = [r.get("model_name", "") for r in rows]
        download_cache_for_models(
            repo_ids=repo_ids,
            cache_dir=cache_dir,
            token=args.token,
            force=args.force_refresh,
        )


if __name__ == "__main__":
    main()
